# vanilla-carousel
A vanilla javascript carousel
